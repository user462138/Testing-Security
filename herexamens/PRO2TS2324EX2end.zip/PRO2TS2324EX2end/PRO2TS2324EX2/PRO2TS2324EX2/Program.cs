﻿// See https://aka.ms/new-console-template for more information

using PRO2TS2324EX2;

ResultsService resultsService = new ResultsService();
Results results = resultsService.GetResults("janvandenpoel");
Console.WriteLine("Test");

