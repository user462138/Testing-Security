using Microsoft.VisualStudio.TestTools.UnitTesting.Logging;
using Moq;

namespace PRO2TS2324EX2.UnitTests
{
    [TestClass]
    public class Tests
    {
        private Mock<ResultsService> resultService = null;
        private Mock<MailService> mailService = null;
        private Mock<RegisterService> registerService = null;
        private Mock<Logger> logger = null;
        private Mock<Results> results = null;
        private Subscriptor subscriptor;
        private Mock<IMailService> mockMailService;
        private Mock<IRegisterService> mockRegisterService;
        private Mock<IResultsService> mockResultService;

        public void Initialize()
        {
            resultService = new Mock<ResultsService>();
            mailService = new Mock<MailService>();
            registerService = new Mock<RegisterService>();
            logger = new Mock<Logger>();
            results = new Mock<Results>();
            mockMailService = new Mock<IMailService>();
            mockRegisterService = new Mock<IRegisterService>();
            mockResultService = new Mock<IResultsService>();
        }

        [TestMethod]
        public void MailStudentNogoWhenStudentFailsBothTests()
        {
            Results resultsStudent = new Results()
            {
                logisch_denken = 3,
                werkethiek = 3
            };
            string student = "janvandenpoel";


            Results results = resultService.Setup(x => x.GetResults(student)).Returns(resultsStudent);
            Assert.AreEqual(3, 3);
        }
    }
}