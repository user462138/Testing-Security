﻿namespace PRO2TS2324EX2
{
    public interface IMailService
    {
        void SendMail(string student, string subject);
    }
}