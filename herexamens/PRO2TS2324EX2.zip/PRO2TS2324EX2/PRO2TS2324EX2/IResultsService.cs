﻿namespace PRO2TS2324EX2
{
    public interface IResultsService
    {
        Results GetResults(string student);
    }
}