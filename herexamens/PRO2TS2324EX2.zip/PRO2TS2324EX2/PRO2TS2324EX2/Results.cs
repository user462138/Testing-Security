﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRO2TS2324EX2;

public class Results
{
    public int logisch_denken { get; set; }
    public int werkethiek { get; set; }
}

