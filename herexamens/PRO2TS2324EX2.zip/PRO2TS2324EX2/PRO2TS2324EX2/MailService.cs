﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRO2TS2324EX2;

public class MailService : IMailService
{
    public void SendMail(string student, string subject)
    {
        // to be implemented
    }
}
